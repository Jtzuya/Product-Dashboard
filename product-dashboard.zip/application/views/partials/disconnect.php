    <script src="<?= base_url('/assets/js/main.js')?>"></script>
    </body>
</html>